
/*
 ******************************************************************************
 * Filename     :   dcc_wisdec.c
 * Modulename   :   dcc_wisdec.c
 * Description  :   Example of using the DCC library. This code can be used for <br>
 *                  for controlling turnouts, but using it is at own risk. 
 * Author Name  :   Robert Evers
 *******************************************************************************/

 /* 
  ******************************************************************************
  * Standard include files
  ******************************************************************************
  */

#include <avr\io.h>
#include <avr\interrupt.h>
#include <inttypes.h>
#include "dcc_module.h"

/*
 *******************************************************************************************
 * Macro definitions
 *******************************************************************************************
 */
#define LED_BLINK_COUNT_LIMIT                40000		/**< Counter for led blinking */
#define DCC_SET_ADRESS                       1   	    /**< Decoder address, in this example address 1, turnout number 1..2 */
#define OUTPUT_SWITCH_OFF_TIME               2			/**< Time to de-activate the output */

/*
 *******************************************************************************************
 * Types
 *******************************************************************************************
  */

/*
 *******************************************************************************************
 * Variables
 *******************************************************************************************
 */

/*
 *******************************************************************************************
 * Prototypes
 *******************************************************************************************
 */

/*
 *******************************************************************************************
 * Routines implementation
 *******************************************************************************************
 */

int main(void)
{
   /* Declare variables for addres and data */
   uint8_t                                 Index;
   uint16_t                                DCC_Address;
   uint8_t                                 DCC_DataAct;
   uint8_t                                 DCC_DataPrev;
   uint16_t                                LedBlinkCnt;
   uint8_t                                 OutputOff[2];
   tDccInfo                                tDataReceived;

   /* Clear the activate array */
   for (Index = 0; Index < 2; Index++)
   {
      OutputOff[Index] = 0;
   }

   /* Set intial values of used variables */
   LedBlinkCnt = 0;
   DCC_Address = 0;
   DCC_DataAct = 0;
   DCC_DataPrev = 255;

   /* Set led output and two pins for control output */
   DDRB = (1 << PB4) | (1 << PB0) | (1 << PB2);
   PORTB &= ~(1<<PB0);
   PORTB &= ~(1<<PB2);
   PORTB &= ~(1<<PB4);

   /* Initialize the DCC module */
   DCC_Module_Init();

   /* Enable the global interrupt */
   sei();

   /* Main neverending loop */
   while (1)
   {
      /* Increase LED blinkcounter, and handle blinking if counter expired */
      LedBlinkCnt++;

      if (LedBlinkCnt > LED_BLINK_COUNT_LIMIT)
      {
         /* Toggle to blink LED */
         LedBlinkCnt = 0;
         PORTB ^= (1<<PB4);

         /* DCC does not transmit off command, so using a simple counter the corresponding output is disabled after a
          * certain time */
         for (Index = 0; Index < 2; Index++)
         {
            OutputOff[Index]++;

            if (OutputOff[Index] >= OUTPUT_SWITCH_OFF_TIME)
            {
               OutputOff[Index] = OUTPUT_SWITCH_OFF_TIME;
			   
			   switch (Index)
               {
                  case 0:
                     PORTB &= ~(1 << PB0);
                     break;
                  case 1:
                     PORTB &= ~(1 << PB2);
                     break;
               }
            }
         }
      }

      /* Check for new data */
      tDataReceived = DCC_CheckForNewInfo(&DCC_Address, &DCC_DataAct);

      /* New data received? */
      if (tDataReceived == DCC_NEW_INFO)
      {
         /* Address valid, process it */
         if (DCC_Address == DCC_SET_ADRESS)
         {
            /* Digital controls repeat DCC data, just process one.... */
            if (DCC_DataAct != DCC_DataPrev)
            {
               DCC_DataPrev = DCC_DataAct;
               OutputOff[DCC_DataAct] = 0;

               /* Now depending on value, set an output */
               switch (DCC_DataAct)
               {
                  case 0:
                     PORTB |= (1 << PB0);
                     break;
                  case 1:
                     PORTB |= (1 << PB2);
                     break;
               }
            }
         }
      }
   }
}
