
/*
 ******************************************************************************
 * mm_example.c
 * Example of using the MM object file.
 * The example demonstrates the use of functions to create a guage decoder.
 * The example is for MM address 1. Other decoder value addresses can be found 
 * in the table listed here http://home.arcor.de/dr.koenig/digital/verbess.htm
 ******************************************************************************
 */

/* Standard include files */
#include <avr\io.h>
#include <inttypes.h>
#include <avr\interrupt.h>
#include "mm_module.h"

/* Defines */
#define MM_SET_ADRESS 0xC0                                                     /* The decoder address, in this example
                                                                                * MM address 1 */
#define LED_BLINK_COUNT_LIMIT 65500

/* Main routine */
int main(void)
{
   /* Declare variables for addres and data */
   uint8_t                                 MM_Address;
   uint8_t                                 MM_Data;
   tMMInfo                                 tDataReceived;
   uint16_t                                LedBlinkCnt;

   /* Set intial values of various used variables */
   MM_Address = 0;
   MM_Data = 0;
   LedBlinkCnt = 0;
   tDataReceived = MM_NO_NEW_INFO;

   /* Set PortB as output */
   DDRB = 0xFF;
   PORTB = 0x00;

   /* Initialize the MM module */
   MM_Module_Init();

   /* Set Blink LED output. Set the pins using |=, &= or ^=, do not use PORTD = xx. This will overide settings created
    * in MM_Module_Init */
   DDRD |= (1 << PD3);
   PORTD |= (1 << PD3);

   /* Enable the global interrupt */
   sei();

   /* Main neverending loop */
   while (1)
   {
      /* Increase LED blinkcounter, and handle blinking if counter expired */
      LedBlinkCnt++;

      if (LedBlinkCnt > LED_BLINK_COUNT_LIMIT)
      {
         PORTD ^= (1 << PD3);                                                  /* Toggle to blink LED */
         LedBlinkCnt = 0;
      }

      /* Check for new data */
      tDataReceived = MM_CheckForNewInfo(&MM_Address, &MM_Data);

      /* New data received? */
      if (tDataReceived == MM_NEW_INFO)
      {
         if (MM_Address == MM_SET_ADRESS)
         {
            /* Bit 4 high for activating a turnout?? */
            if (MM_Data & 0x08)
            {
               /* yes, process it, first remove bit 4 */
               MM_Data -= 8;

               /* Now depending on value, set a output */
               switch (MM_Data)
               {
                  case 0:
                     PORTB |= (1 << PB0);
                     break;
                  case 1:
                     PORTB |= (1 << PB1);
                     break;
                  case 2:
                     PORTB |= (1 << PB2);
                     break;
                  case 3:
                     PORTB |= (1 << PB3);
                     break;
                  case 4:
                     PORTB |= (1 << PB4);
                     break;
                  case 5:
                     PORTB |= (1 << PB5);
                     break;
                  case 6:
                     PORTB |= (1 << PB6);
                     break;
                  case 7:
                     PORTB |= (1 << PB7);
                     break;
               }
            }
            else
            {
               /* Bit 4 was low, reset all outputs */
               PORTB = 0;
            }
         }
      }
   }
}
