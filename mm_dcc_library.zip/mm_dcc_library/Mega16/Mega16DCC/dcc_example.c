
/*
 ******************************************************************************
 * Filename     :   dcc_wisdec.c
 * Modulename   :   dcc_wisdec.c
 * Description  :   Example of using the DCC library. This code can be used for <br>
 *                  for controlling turnouts, but using it is at own risk. 
 * Author Name  :   Robert Evers
 *******************************************************************************/

 /* 
  ******************************************************************************
  * Standard include files
  ******************************************************************************
  */

#include <avr\io.h>
#include <avr\interrupt.h>
#include <inttypes.h>
#include "dcc_module.h"

/*
 *******************************************************************************************
 * Macro definitions
 *******************************************************************************************
 */
#define LED_BLINK_COUNT_LIMIT                40000		/**< Counter for led blinking */
#define DCC_SET_ADRESS                       1   	    /**< Decoder address, in this example address 1, turnout number 1..4 */
#define OUTPUT_SWITCH_OFF_TIME               2			/**< Time to active the output */

/*
 *******************************************************************************************
 * Types
 *******************************************************************************************
  */

/*
 *******************************************************************************************
 * Variables
 *******************************************************************************************
 */

/*
 *******************************************************************************************
 * Prototypes
 *******************************************************************************************
 */

/*
 *******************************************************************************************
 * Routines implementation
 *******************************************************************************************
 */

int main(void)
{
   /* Declare variables for addres and data */
   uint8_t                                 Index;
   uint16_t                                DCC_Address;
   uint8_t                                 DCC_DataAct;
   uint8_t                                 DCC_DataPrev;
   uint16_t                                LedBlinkCnt;
   uint8_t                                 OutputOff[8];
   tDccInfo                                tDataReceived;

   /* Clear the activate array */
   for (Index = 0; Index < 8; Index++)
   {
      OutputOff[Index] = 0;
   }

   /* Set intial values of used variables */
   LedBlinkCnt = 0;
   DCC_Address = 0;
   DCC_DataAct = 0;
   DCC_DataPrev = 255;

   /* Set PortB as output and all off */
   DDRB = 0xFF;
   PORTB = 0x00;

   /* Initialize the DCC module */
   DCC_Module_Init();

   /* Set Blink LED output. Set the pins using |=, &= or ^=, do not use PORTD = xx. PORTD = xx will overide settings
    * created in DCC_Module_Init */
   DDRD |= (1 << PD3);
   PORTD |= (1 << PD3);

   /* Enable the global interrupt */
   sei();

   /* Main neverending loop */
   while (1)
   {
      /* Increase LED blinkcounter, and handle blinking if counter expired */
      LedBlinkCnt++;

      if (LedBlinkCnt > LED_BLINK_COUNT_LIMIT)
      {
         /* Toggle to blink LED */
         PORTD ^= (1 << PD3);
         LedBlinkCnt = 0;

         /* DCC does not transmit off command, so using a simple counter the corresponding output is disabled after a
          * certain time */
         for (Index = 0; Index < 8; Index++)
         {
            OutputOff[Index]++;

            if (OutputOff[Index] >= OUTPUT_SWITCH_OFF_TIME)
            {
               PORTB &= ~(1 << Index);
               OutputOff[Index] = OUTPUT_SWITCH_OFF_TIME;
            }
         }
      }

      /* Check for new data */
      tDataReceived = DCC_CheckForNewInfo(&DCC_Address, &DCC_DataAct);

      /* New data received? */
      if (tDataReceived == DCC_NEW_INFO)
      {
         /* Address valid, process it */
         if (DCC_Address == DCC_SET_ADRESS)
         {
            /* Digital controls repeat DCC data, just process one.... */
            if (DCC_DataAct != DCC_DataPrev)
            {
               DCC_DataPrev = DCC_DataAct;
               OutputOff[DCC_DataAct] = 0;

               /* Now depending on value, set a output */
               switch (DCC_DataAct)
               {
                  case 0:
                     PORTB |= (1 << PB0);
                     break;
                  case 1:
                     PORTB |= (1 << PB1);
                     break;
                  case 2:
                     PORTB |= (1 << PB2);
                     break;
                  case 3:
                     PORTB |= (1 << PB3);
                     break;
                  case 4:
                     PORTB |= (1 << PB4);
                     break;
                  case 5:
                     PORTB |= (1 << PB5);
                     break;
                  case 6:
                     PORTB |= (1 << PB6);
                     break;
                  case 7:
                     PORTB |= (1 << PB7);
                     break;
               }
            }
         }
      }
   }
}
